import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Wello World</p>
      </header>
    </div>
  );
}

export default App;
